from django.apps import AppConfig


class PlacementAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'placement_app'
